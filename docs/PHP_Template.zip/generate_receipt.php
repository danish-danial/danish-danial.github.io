<?php
use setasign\Fpdi\Fpdi; 

require_once ('lib/pdf/fpdf.php'); 
require_once ('lib/pdf/autoload.php'); 

include ('connect_db.php'); 

func_setReqVar(); 

// agreement
$sql = "SELECT
*
FROM user WHERE id =" .$_GET['id']; 

db_select($sql); 
if (db_rowcount() > 0) { 
    func_setSelectVar(); 
} 

$pdf = new Fpdi('P', 'mm', array(208, 302)); 
$pdf->AddPage(); 
$pdf->setSourceFile('assets/doc/example.pdf'); 
$tplIdx = $pdf->importPage(1); 
$pdf->useTemplate($tplIdx); 

$pdf->SetFont('Helvetica', '', 10); 
$pdf->SetTextColor(0, 0, 0); 
$pdf->SetXY(100, 36); 
$pdf->Write(0, $name); 

$pdf->SetXY(155, 36); 
$pdf->Write(0, $age); 

ob_clean();
header("Content-type:application/pdf"); 
header("Content-Disposition:attachment;filename='downloaded.pdf'"); 
$pdf->Output(); 
ob_end_flush(); 
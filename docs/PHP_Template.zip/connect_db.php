<?php
include "lib/setup.php";

// Select the table from database
$sql = "SELECT * FROM user WHERE id IS NOT NULL";
db_select($sql);

// If the database row is above the 0, the system will automatically generate the database variable
if (db_rowcount() > 0) {
    func_setSelectVar();
    echo "Database Connected";
} else {
    echo "Database not Connected";
}

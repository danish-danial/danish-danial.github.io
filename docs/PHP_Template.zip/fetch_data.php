<?php include "connect_db.php"; ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <button><a href="add_data.php">Insert New Data</a></button>
    <table class="table">
        <thead>
            <tr>
                <th>Number</th>
                <th>Name</th>
                <th>Age</th>
                <th>Edit</th>
                <th>Print</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // For loop in the table
            if (db_rowcount() > 0) {
                for ($i = 0; $i < db_rowcount(); $i++) {
                    $status = "";
                    if (func_getOffset() >= 10) {
                        $no = func_getOffset() + 1 + $i;
                    } else {
                        $no = $i + 1;
                    }
                    echo "<tr>
                                <td>" . $no . "</td>
                                <td>" . db_get($i, 1) . "</td>
                                <td>" . db_get($i, 2) . "</td>
                                <td><a href='edit_data.php?id=" . db_get($i, 0) . "'>Edit</a></td>
                                <td><a href='generate_receipt.php?id=" . db_get($i, 0) . "'>Print</a></td>
                                </tr>";
                }
            }
            ?>
        </tbody>
    </table>
</body>

</html>
<?php
include "connect_db.php";

// Add data into database
func_setReqVar();

if (isset($btn_save)) {
    func_setValid("Y");

    if (func_isValid()) {
        $sql = "INSERT INTO user
              (
              name,
              age
              )
              VALUES
              (
              '" . conv_text_to_dbtext3($name) . "',
              '" . conv_text_to_dbtext3($age) . "'
              )
              ";
        //echo $sql;
        db_update($sql);

        vali_redirect('fetch_data.php');
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <form method="POST">

        <div class="row">
            <div class="col-md-4">
                <div class="form-group label-floating">
                    <label class="control-label">Name</label>
                    <input type="text" class="form-control" name="name">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group label-floating">
                    <label class="control-label">Age</label>
                    <input type="text" class="form-control" name="age">
                </div>
            </div>
        </div>

        <div class="form-group">
            <div class="text-center">
                <button type="submit" class="btn btn-success" name="btn_save">Save</button>
                <button type="button" class="btn btn-info"
                    onclick="location.href='fetch_data.php'"
                    name="btn_cancel">Cancel</button>
            </div>
        </div>
    </form>
</body>

</html>